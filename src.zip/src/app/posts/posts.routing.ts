import { Routes } from "@angular/router";
import { PostComponent } from "./post.component";

export const postRoutes: Routes = [{ path:'',component:PostComponent }];