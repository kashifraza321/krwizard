import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-oportunite',
  templateUrl: './oportunite.component.html',
  styleUrls: ['./oportunite.component.scss']
})
export class OportuniteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {

    
  }

}
